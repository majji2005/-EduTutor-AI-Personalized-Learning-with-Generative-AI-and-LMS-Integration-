import { google } from "googleapis"

const oauth2Client = new google.auth.OAuth2(
  process.env.GOOGLE_CLIENT_ID,
  process.env.GOOGLE_CLIENT_SECRET,
  process.env.GOOGLE_REDIRECT_URI,
)

export class GoogleClassroomService {
  private classroom: any

  constructor(accessToken: string) {
    oauth2Client.setCredentials({ access_token: accessToken })
    this.classroom = google.classroom({ version: "v1", auth: oauth2Client })
  }

  async getCourses() {
    try {
      const response = await this.classroom.courses.list({
        teacherId: "me",
        courseStates: ["ACTIVE"],
      })
      return response.data.courses || []
    } catch (error) {
      console.error("Error fetching Google Classroom courses:", error)
      throw error
    }
  }

  async getStudents(courseId: string) {
    try {
      const response = await this.classroom.courses.students.list({
        courseId,
      })
      return response.data.students || []
    } catch (error) {
      console.error("Error fetching students:", error)
      throw error
    }
  }

  async createAssignment(courseId: string, assignment: any) {
    try {
      const response = await this.classroom.courses.courseWork.create({
        courseId,
        requestBody: assignment,
      })
      return response.data
    } catch (error) {
      console.error("Error creating assignment:", error)
      throw error
    }
  }

  async submitGrade(courseId: string, courseWorkId: string, studentId: string, grade: number) {
    try {
      const response = await this.classroom.courses.courseWork.studentSubmissions.patch({
        courseId,
        courseWorkId,
        id: studentId,
        updateMask: "assignedGrade,draftGrade",
        requestBody: {
          assignedGrade: grade,
          draftGrade: grade,
        },
      })
      return response.data
    } catch (error) {
      console.error("Error submitting grade:", error)
      throw error
    }
  }

  static getAuthUrl() {
    const scopes = [
      "https://www.googleapis.com/auth/classroom.courses.readonly",
      "https://www.googleapis.com/auth/classroom.rosters.readonly",
      "https://www.googleapis.com/auth/classroom.coursework.students",
      "https://www.googleapis.com/auth/classroom.student-submissions.students.readonly",
    ]

    return oauth2Client.generateAuthUrl({
      access_type: "offline",
      scope: scopes,
      prompt: "consent",
    })
  }

  static async getTokens(code: string) {
    try {
      const { tokens } = await oauth2Client.getToken(code)
      return tokens
    } catch (error) {
      console.error("Error getting tokens:", error)
      throw error
    }
  }
}
