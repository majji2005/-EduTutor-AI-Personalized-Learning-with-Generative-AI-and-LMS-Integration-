-- Enable RLS on all tables
ALTER TABLE public.profiles ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.courses ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.course_enrollments ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.quizzes ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.questions ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.quiz_attempts ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.student_analytics ENABLE ROW LEVEL SECURITY;

-- Profiles policies
CREATE POLICY "Users can view own profile" ON public.profiles
  FOR SELECT USING (auth.uid() = id);

CREATE POLICY "Users can update own profile" ON public.profiles
  FOR UPDATE USING (auth.uid() = id);

-- Courses policies
CREATE POLICY "Anyone can view courses" ON public.courses
  FOR SELECT USING (true);

CREATE POLICY "Educators can create courses" ON public.courses
  FOR INSERT WITH CHECK (
    auth.uid() = educator_id AND 
    EXISTS (SELECT 1 FROM public.profiles WHERE id = auth.uid() AND role = 'educator')
  );

CREATE POLICY "Educators can update own courses" ON public.courses
  FOR UPDATE USING (auth.uid() = educator_id);

-- Course enrollments policies
CREATE POLICY "Students can view own enrollments" ON public.course_enrollments
  FOR SELECT USING (auth.uid() = student_id);

CREATE POLICY "Students can enroll in courses" ON public.course_enrollments
  FOR INSERT WITH CHECK (
    auth.uid() = student_id AND 
    EXISTS (SELECT 1 FROM public.profiles WHERE id = auth.uid() AND role = 'student')
  );

-- Quiz attempts policies
CREATE POLICY "Students can view own attempts" ON public.quiz_attempts
  FOR SELECT USING (auth.uid() = student_id);

CREATE POLICY "Students can create own attempts" ON public.quiz_attempts
  FOR INSERT WITH CHECK (auth.uid() = student_id);

CREATE POLICY "Students can update own attempts" ON public.quiz_attempts
  FOR UPDATE USING (auth.uid() = student_id);

-- Analytics policies
CREATE POLICY "Students can view own analytics" ON public.student_analytics
  FOR SELECT USING (auth.uid() = student_id);

CREATE POLICY "Educators can view course analytics" ON public.student_analytics
  FOR SELECT USING (
    EXISTS (
      SELECT 1 FROM public.courses 
      WHERE id = course_id AND educator_id = auth.uid()
    )
  );
