import { type NextRequest, NextResponse } from "next/server"
import { supabaseServer } from "@/lib/supabase-server"

export async function POST(request: NextRequest) {
  try {
    const { subject, difficulty, questionCount, courseId } = await request.json()

    // Get user from auth header
    const authHeader = request.headers.get("authorization")
    if (!authHeader) {
      return NextResponse.json({ success: false, message: "Unauthorized" }, { status: 401 })
    }

    // Create quiz in database
    const { data: quiz, error: quizError } = await supabaseServer
      .from("quizzes")
      .insert({
        title: `${subject} Quiz - ${difficulty}`,
        description: `AI-generated ${subject} quiz with ${questionCount} questions`,
        course_id: courseId,
        difficulty,
        time_limit: questionCount * 2, // 2 minutes per question
        created_by: "user-id", // You'd get this from the auth token
      })
      .select()
      .single()

    if (quizError) {
      return NextResponse.json({ success: false, message: quizError.message }, { status: 500 })
    }

    // Generate AI questions (mock for now)
    const questions = Array.from({ length: questionCount }, (_, i) => ({
      quiz_id: quiz.id,
      question_text: `AI-generated ${subject} question ${i + 1}?`,
      question_type: "multiple_choice",
      options: ["Option A", "Option B", "Option C", "Option D"],
      correct_answer: "Option A",
      explanation: `This is the AI-generated explanation for question ${i + 1}`,
      points: 1,
      order_index: i + 1,
    }))

    // Insert questions
    const { error: questionsError } = await supabaseServer.from("questions").insert(questions)

    if (questionsError) {
      return NextResponse.json({ success: false, message: questionsError.message }, { status: 500 })
    }

    return NextResponse.json({
      success: true,
      quiz: {
        ...quiz,
        questions,
      },
    })
  } catch (error) {
    return NextResponse.json({ success: false, message: "Failed to generate quiz" }, { status: 500 })
  }
}
