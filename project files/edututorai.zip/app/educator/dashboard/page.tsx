"use client"

import { useEffect, useState } from "react"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Users, BookOpen, BarChart3, Plus, LogOut, ExternalLink, CheckCircle, Settings } from "lucide-react"
import { supabase } from "@/lib/supabase"
import { useRouter } from "next/navigation"
import Link from "next/link"

interface Course {
  id: string
  title: string
  description: string
  subject: string
  student_count: number
}

interface DashboardStats {
  totalStudents: number
  activeCourses: number
  quizzesGenerated: number
  averagePerformance: number
}

export default function EducatorDashboard() {
  // state
  const [user, setUser] = useState<any>(null)
  const [courses, setCourses] = useState<Course[]>([])
  const [stats, setStats] = useState<DashboardStats>({
    totalStudents: 0,
    activeCourses: 0,
    quizzesGenerated: 0,
    averagePerformance: 0,
  })
  const [loading, setLoading] = useState(true)
  const [googleClassroomConnected, setGoogleClassroomConnected] = useState(false)
  const router = useRouter()

  useEffect(() => {
    checkUser()
  }, [])

  const checkUser = async () => {
    const {
      data: { user },
    } = await supabase.auth.getUser()

    if (!user) {
      router.push("/educator/login")
      return
    }

    setUser(user)
    await loadDashboardData(user.id)
  }

  const loadDashboardData = async (userId: string) => {
    try {
      // Load educator's courses with enrollment counts
      const { data: coursesData } = await supabase
        .from("courses")
        .select(`
          id,
          title,
          description,
          subject,
          course_enrollments (count)
        `)
        .eq("educator_id", userId)

      const coursesWithCounts =
        coursesData?.map((course) => ({
          id: course.id,
          title: course.title,
          description: course.description,
          subject: course.subject,
          student_count: course.course_enrollments?.[0]?.count || 0,
        })) || []

      setCourses(coursesWithCounts)

      // Calculate total students across all courses
      const totalStudents = coursesWithCounts.reduce((sum, course) => sum + course.student_count, 0)

      // Load quiz count
      const { count: quizCount } = await supabase
        .from("quizzes")
        .select("*", { count: "exact", head: true })
        .eq("created_by", userId)

      // Load average performance from analytics
      const { data: analyticsData } = await supabase
        .from("student_analytics")
        .select("average_score")
        .in(
          "course_id",
          coursesWithCounts.map((c) => c.id),
        )

      const avgPerformance =
        analyticsData?.length > 0
          ? analyticsData.reduce((sum, record) => sum + record.average_score, 0) / analyticsData.length
          : 0

      setStats({
        totalStudents,
        activeCourses: coursesWithCounts.length,
        quizzesGenerated: quizCount || 0,
        averagePerformance: Math.round(avgPerformance),
      })
    } catch (error) {
      console.error("Error loading dashboard data:", error)
    } finally {
      setLoading(false)
    }
  }

  const handleSignOut = async () => {
    await supabase.auth.signOut()
    router.push("/")
  }

  const handleGoogleClassroomConnect = async () => {
    try {
      const response = await fetch("/api/google-classroom/auth")
      const { authUrl } = await response.json()
      window.location.href = `${authUrl}&state=${user.id}`
    } catch (error) {
      console.error("Error connecting to Google Classroom:", error)
    }
  }

  if (loading) {
    return (
      <div className="min-h-screen bg-gray-50 flex items-center justify-center">
        <div className="text-center">
          <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-blue-600 mx-auto mb-4"></div>
          <p className="text-gray-600">Loading your dashboard...</p>
        </div>
      </div>
    )
  }

  return (
    <div className="min-h-screen bg-gray-50">
      <div className="bg-white border-b">
        <div className="max-w-7xl mx-auto px-4 py-4 flex justify-between items-center">
          <div>
            <h1 className="text-2xl font-bold text-gray-900">Educator Dashboard</h1>
            <p className="text-gray-600">Welcome back, {user?.user_metadata?.full_name || "Educator"}!</p>
          </div>
          <div className="flex gap-2">
            <Button className="bg-blue-600 hover:bg-blue-700" asChild>
              <Link href="/educator/courses/create">
                <Plus className="w-4 h-4 mr-2" />
                Create Course
              </Link>
            </Button>
            <Button variant="outline" onClick={handleSignOut}>
              <LogOut className="w-4 h-4 mr-2" />
              Sign Out
            </Button>
          </div>
        </div>
      </div>

      <div className="max-w-7xl mx-auto px-4 py-8">
        <div className="grid md:grid-cols-4 gap-6 mb-8">
          <Card>
            <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
              <CardTitle className="text-sm font-medium">Total Students</CardTitle>
              <Users className="h-4 w-4 text-muted-foreground" />
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold">{stats.totalStudents}</div>
            </CardContent>
          </Card>
          <Card>
            <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
              <CardTitle className="text-sm font-medium">Active Courses</CardTitle>
              <BookOpen className="h-4 w-4 text-muted-foreground" />
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold">{stats.activeCourses}</div>
            </CardContent>
          </Card>
          <Card>
            <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
              <CardTitle className="text-sm font-medium">Quizzes Generated</CardTitle>
              <BarChart3 className="h-4 w-4 text-muted-foreground" />
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold">{stats.quizzesGenerated}</div>
            </CardContent>
          </Card>
          <Card>
            <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
              <CardTitle className="text-sm font-medium">Avg. Performance</CardTitle>
              <BarChart3 className="h-4 w-4 text-muted-foreground" />
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold">{stats.averagePerformance}%</div>
            </CardContent>
          </Card>
        </div>

        <div className="grid md:grid-cols-2 gap-6">
          <Card>
            <CardHeader>
              <CardTitle>Your Courses</CardTitle>
              <CardDescription>Manage your teaching materials</CardDescription>
            </CardHeader>
            <CardContent className="space-y-4">
              {courses.length > 0 ? (
                courses.map((course) => (
                  <div key={course.id} className="flex items-center justify-between p-3 border rounded-lg">
                    <div>
                      <p className="font-medium">{course.title}</p>
                      <p className="text-sm text-gray-500">{course.student_count} students enrolled</p>
                    </div>
                    <Button variant="outline" size="sm">
                      Manage
                    </Button>
                  </div>
                ))
              ) : (
                <div className="text-center py-8">
                  <p className="text-gray-500 mb-4">No courses created yet.</p>
                  <Button className="bg-blue-600 hover:bg-blue-700" asChild>
                    <Link href="/educator/courses/create">
                      <Plus className="w-4 h-4 mr-2" />
                      Create Your First Course
                    </Link>
                  </Button>
                </div>
              )}
            </CardContent>
          </Card>
          <Card>
            <CardHeader>
              <CardTitle>Google Classroom Integration</CardTitle>
              <CardDescription>Sync your courses with Google Classroom</CardDescription>
            </CardHeader>
            <CardContent className="space-y-4">
              {googleClassroomConnected ? (
                <div className="text-center py-4">
                  <div className="w-12 h-12 bg-green-100 rounded-full flex items-center justify-center mx-auto mb-3">
                    <CheckCircle className="w-6 h-6 text-green-600" />
                  </div>
                  <p className="font-medium text-green-800">Connected to Google Classroom</p>
                  <p className="text-sm text-gray-600 mb-4">Your courses are synced automatically</p>
                  <Button variant="outline" size="sm">
                    <Settings className="w-4 h-4 mr-2" />
                    Manage Integration
                  </Button>
                </div>
              ) : (
                <div className="text-center py-4">
                  <div className="w-12 h-12 bg-blue-100 rounded-full flex items-center justify-center mx-auto mb-3">
                    <ExternalLink className="w-6 h-6 text-blue-600" />
                  </div>
                  <p className="font-medium mb-2">Connect Google Classroom</p>
                  <p className="text-sm text-gray-600 mb-4">
                    Import courses, sync student rosters, and automatically grade assignments
                  </p>
                  <Button onClick={handleGoogleClassroomConnect} className="bg-blue-600 hover:bg-blue-700">
                    <ExternalLink className="w-4 h-4 mr-2" />
                    Connect Now
                  </Button>
                </div>
              )}
            </CardContent>
          </Card>

          <Card>
            <CardHeader>
              <CardTitle>Student Analytics</CardTitle>
              <CardDescription>Performance insights and trends</CardDescription>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="space-y-2">
                <div className="flex justify-between">
                  <span className="font-medium">Quiz Completion Rate</span>
                  <span className="text-sm font-semibold text-green-600">94%</span>
                </div>
                <div className="w-full bg-gray-200 rounded-full h-2">
                  <div className="bg-green-600 h-2 rounded-full" style={{ width: "94%" }}></div>
                </div>
              </div>
              <div className="space-y-2">
                <div className="flex justify-between">
                  <span className="font-medium">Average Score</span>
                  <span className="text-sm font-semibold text-blue-600">{stats.averagePerformance}%</span>
                </div>
                <div className="w-full bg-gray-200 rounded-full h-2">
                  <div className="bg-blue-600 h-2 rounded-full" style={{ width: `${stats.averagePerformance}%` }}></div>
                </div>
              </div>
              <div className="space-y-2">
                <div className="flex justify-between">
                  <span className="font-medium">Engagement Rate</span>
                  <span className="text-sm font-semibold text-purple-600">88%</span>
                </div>
                <div className="w-full bg-gray-200 rounded-full h-2">
                  <div className="bg-purple-600 h-2 rounded-full" style={{ width: "88%" }} />
                </div>
              </div>
            </CardContent>
          </Card>
        </div>
      </div>
    </div>
  )
}
