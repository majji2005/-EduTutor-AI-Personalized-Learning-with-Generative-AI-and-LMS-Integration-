"use client"

import { useState } from "react"
import { Dialog, DialogContent, DialogDescription, DialogHeader, DialogTitle } from "@/components/ui/dialog"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Textarea } from "@/components/ui/textarea"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { FileText, Video, ClipboardList, Upload, Plus, Trash2 } from "lucide-react"

interface Lesson {
  id: string
  title: string
  content_type: "text" | "video" | "quiz" | "file"
  duration_minutes: number
  content: any
}

interface LessonEditorProps {
  lesson: Lesson
  onSave: (lesson: Partial<Lesson>) => void
  onClose: () => void
}

export function LessonEditor({ lesson, onSave, onClose }: LessonEditorProps) {
  const [editedLesson, setEditedLesson] = useState<Lesson>({ ...lesson })

  const handleSave = () => {
    onSave(editedLesson)
  }

  const renderContentEditor = () => {
    switch (editedLesson.content_type) {
      case "text":
        return (
          <div className="space-y-4">
            <div className="space-y-2">
              <Label htmlFor="text-content">Lesson Content</Label>
              <Textarea
                id="text-content"
                placeholder="Write your lesson content here..."
                rows={10}
                value={editedLesson.content.text || ""}
                onChange={(e) =>
                  setEditedLesson({
                    ...editedLesson,
                    content: { ...editedLesson.content, text: e.target.value },
                  })
                }
              />
            </div>
            <div className="space-y-2">
              <Label htmlFor="learning-objectives">Learning Objectives</Label>
              <Textarea
                id="learning-objectives"
                placeholder="What will students learn from this lesson?"
                rows={3}
                value={editedLesson.content.objectives || ""}
                onChange={(e) =>
                  setEditedLesson({
                    ...editedLesson,
                    content: { ...editedLesson.content, objectives: e.target.value },
                  })
                }
              />
            </div>
          </div>
        )

      case "video":
        return (
          <div className="space-y-4">
            <div className="space-y-2">
              <Label htmlFor="video-url">Video URL</Label>
              <Input
                id="video-url"
                placeholder="https://youtube.com/watch?v=... or upload video file"
                value={editedLesson.content.video_url || ""}
                onChange={(e) =>
                  setEditedLesson({
                    ...editedLesson,
                    content: { ...editedLesson.content, video_url: e.target.value },
                  })
                }
              />
            </div>
            <div className="space-y-2">
              <Label htmlFor="video-description">Video Description</Label>
              <Textarea
                id="video-description"
                placeholder="Describe what's covered in this video"
                rows={4}
                value={editedLesson.content.description || ""}
                onChange={(e) =>
                  setEditedLesson({
                    ...editedLesson,
                    content: { ...editedLesson.content, description: e.target.value },
                  })
                }
              />
            </div>
            <div className="grid grid-cols-2 gap-4">
              <div className="space-y-2">
                <Label htmlFor="video-start">Start Time (seconds)</Label>
                <Input
                  id="video-start"
                  type="number"
                  min="0"
                  value={editedLesson.content.start_time || 0}
                  onChange={(e) =>
                    setEditedLesson({
                      ...editedLesson,
                      content: { ...editedLesson.content, start_time: Number.parseInt(e.target.value) || 0 },
                    })
                  }
                />
              </div>
              <div className="space-y-2">
                <Label htmlFor="video-end">End Time (seconds)</Label>
                <Input
                  id="video-end"
                  type="number"
                  min="0"
                  value={editedLesson.content.end_time || 0}
                  onChange={(e) =>
                    setEditedLesson({
                      ...editedLesson,
                      content: { ...editedLesson.content, end_time: Number.parseInt(e.target.value) || 0 },
                    })
                  }
                />
              </div>
            </div>
          </div>
        )

      case "quiz":
        return <QuizEditor lesson={editedLesson} setLesson={setEditedLesson} />

      case "file":
        return (
          <div className="space-y-4">
            <div className="space-y-2">
              <Label>File Upload</Label>
              <div className="border-2 border-dashed border-gray-300 rounded-lg p-6 text-center">
                <Upload className="w-8 h-8 text-gray-400 mx-auto mb-2" />
                <p className="text-sm text-gray-600">Click to upload or drag and drop</p>
                <p className="text-xs text-gray-500">PDF, DOC, PPT, or other files up to 10MB</p>
              </div>
            </div>
            <div className="space-y-2">
              <Label htmlFor="file-description">File Description</Label>
              <Textarea
                id="file-description"
                placeholder="Describe this resource and how students should use it"
                rows={4}
                value={editedLesson.content.description || ""}
                onChange={(e) =>
                  setEditedLesson({
                    ...editedLesson,
                    content: { ...editedLesson.content, description: e.target.value },
                  })
                }
              />
            </div>
          </div>
        )

      default:
        return <div>Select a content type to continue</div>
    }
  }

  return (
    <Dialog open={true} onOpenChange={onClose}>
      <DialogContent className="max-w-4xl max-h-[90vh] overflow-y-auto">
        <DialogHeader>
          <DialogTitle>Edit Lesson</DialogTitle>
          <DialogDescription>Configure your lesson content and settings</DialogDescription>
        </DialogHeader>

        <div className="grid grid-cols-3 gap-6">
          {/* Lesson Settings */}
          <div className="space-y-6">
            <Card>
              <CardHeader>
                <CardTitle className="text-lg">Lesson Settings</CardTitle>
              </CardHeader>
              <CardContent className="space-y-4">
                <div className="space-y-2">
                  <Label htmlFor="lesson-title">Lesson Title</Label>
                  <Input
                    id="lesson-title"
                    value={editedLesson.title}
                    onChange={(e) => setEditedLesson({ ...editedLesson, title: e.target.value })}
                  />
                </div>

                <div className="space-y-2">
                  <Label htmlFor="content-type">Content Type</Label>
                  <Select
                    value={editedLesson.content_type}
                    onValueChange={(value: any) => setEditedLesson({ ...editedLesson, content_type: value })}
                  >
                    <SelectTrigger>
                      <SelectValue />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="text">
                        <div className="flex items-center gap-2">
                          <FileText className="w-4 h-4" />
                          Text Lesson
                        </div>
                      </SelectItem>
                      <SelectItem value="video">
                        <div className="flex items-center gap-2">
                          <Video className="w-4 h-4" />
                          Video Lesson
                        </div>
                      </SelectItem>
                      <SelectItem value="quiz">
                        <div className="flex items-center gap-2">
                          <ClipboardList className="w-4 h-4" />
                          Quiz
                        </div>
                      </SelectItem>
                      <SelectItem value="file">
                        <div className="flex items-center gap-2">
                          <Upload className="w-4 h-4" />
                          File/Resource
                        </div>
                      </SelectItem>
                    </SelectContent>
                  </Select>
                </div>

                <div className="space-y-2">
                  <Label htmlFor="duration">Duration (minutes)</Label>
                  <Input
                    id="duration"
                    type="number"
                    min="0"
                    value={editedLesson.duration_minutes}
                    onChange={(e) =>
                      setEditedLesson({ ...editedLesson, duration_minutes: Number.parseInt(e.target.value) || 0 })
                    }
                  />
                </div>
              </CardContent>
            </Card>
          </div>

          {/* Content Editor */}
          <div className="col-span-2">
            <Card>
              <CardHeader>
                <CardTitle className="text-lg">Lesson Content</CardTitle>
                <CardDescription>Create engaging content for your students</CardDescription>
              </CardHeader>
              <CardContent>{renderContentEditor()}</CardContent>
            </Card>
          </div>
        </div>

        <div className="flex justify-end gap-3 pt-6 border-t">
          <Button variant="outline" onClick={onClose}>
            Cancel
          </Button>
          <Button onClick={handleSave}>Save Lesson</Button>
        </div>
      </DialogContent>
    </Dialog>
  )
}

function QuizEditor({ lesson, setLesson }: { lesson: any; setLesson: (lesson: any) => void }) {
  const [questions, setQuestions] = useState(lesson.content.questions || [])

  const addQuestion = () => {
    const newQuestion = {
      id: Date.now().toString(),
      question: "",
      type: "multiple_choice",
      options: ["", "", "", ""],
      correct_answer: 0,
      explanation: "",
    }
    const updatedQuestions = [...questions, newQuestion]
    setQuestions(updatedQuestions)
    setLesson({ ...lesson, content: { ...lesson.content, questions: updatedQuestions } })
  }

  const updateQuestion = (questionId: string, updates: any) => {
    const updatedQuestions = questions.map((q: any) => (q.id === questionId ? { ...q, ...updates } : q))
    setQuestions(updatedQuestions)
    setLesson({ ...lesson, content: { ...lesson.content, questions: updatedQuestions } })
  }

  const deleteQuestion = (questionId: string) => {
    const updatedQuestions = questions.filter((q: any) => q.id !== questionId)
    setQuestions(updatedQuestions)
    setLesson({ ...lesson, content: { ...lesson.content, questions: updatedQuestions } })
  }

  return (
    <div className="space-y-4">
      <div className="flex items-center justify-between">
        <h3 className="text-lg font-medium">Quiz Questions</h3>
        <Button onClick={addQuestion} size="sm">
          <Plus className="w-4 h-4 mr-2" />
          Add Question
        </Button>
      </div>

      {questions.length === 0 ? (
        <div className="text-center py-8 border-2 border-dashed border-gray-300 rounded-lg">
          <ClipboardList className="w-8 h-8 text-gray-400 mx-auto mb-2" />
          <p className="text-gray-600">No questions yet. Add your first question to get started.</p>
        </div>
      ) : (
        <div className="space-y-4">
          {questions.map((question: any, index: number) => (
            <Card key={question.id}>
              <CardHeader className="pb-3">
                <div className="flex items-center justify-between">
                  <Badge variant="outline">Question {index + 1}</Badge>
                  <Button variant="ghost" size="sm" onClick={() => deleteQuestion(question.id)}>
                    <Trash2 className="w-4 h-4 text-red-500" />
                  </Button>
                </div>
              </CardHeader>
              <CardContent className="space-y-4">
                <div className="space-y-2">
                  <Label>Question</Label>
                  <Textarea
                    placeholder="Enter your question here..."
                    value={question.question}
                    onChange={(e) => updateQuestion(question.id, { question: e.target.value })}
                  />
                </div>

                <div className="space-y-2">
                  <Label>Answer Options</Label>
                  {question.options.map((option: string, optionIndex: number) => (
                    <div key={optionIndex} className="flex items-center gap-2">
                      <Input
                        placeholder={`Option ${optionIndex + 1}`}
                        value={option}
                        onChange={(e) => {
                          const newOptions = [...question.options]
                          newOptions[optionIndex] = e.target.value
                          updateQuestion(question.id, { options: newOptions })
                        }}
                      />
                      <Button
                        variant={question.correct_answer === optionIndex ? "default" : "outline"}
                        size="sm"
                        onClick={() => updateQuestion(question.id, { correct_answer: optionIndex })}
                      >
                        {question.correct_answer === optionIndex ? "Correct" : "Mark Correct"}
                      </Button>
                    </div>
                  ))}
                </div>

                <div className="space-y-2">
                  <Label>Explanation (Optional)</Label>
                  <Textarea
                    placeholder="Explain why this is the correct answer..."
                    value={question.explanation}
                    onChange={(e) => updateQuestion(question.id, { explanation: e.target.value })}
                  />
                </div>
              </CardContent>
            </Card>
          ))}
        </div>
      )}
    </div>
  )
}
