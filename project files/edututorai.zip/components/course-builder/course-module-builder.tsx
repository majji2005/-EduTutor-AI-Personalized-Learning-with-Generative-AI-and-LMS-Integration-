"use client"

import { useState } from "react"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Textarea } from "@/components/ui/textarea"
import { Badge } from "@/components/ui/badge"
import {
  Plus,
  GripVertical,
  ChevronDown,
  ChevronRight,
  FileText,
  Video,
  ClipboardList,
  Upload,
  Trash2,
  Edit,
} from "lucide-react"
import { LessonEditor } from "./lesson-editor"

interface Module {
  id: string
  title: string
  description: string
  lessons: Lesson[]
  isExpanded: boolean
}

interface Lesson {
  id: string
  title: string
  content_type: "text" | "video" | "quiz" | "file"
  duration_minutes: number
  content: any
}

interface CourseModuleBuilderProps {
  courseData: any
}

export function CourseModuleBuilder({ courseData }: CourseModuleBuilderProps) {
  const [modules, setModules] = useState<Module[]>([])
  const [editingLesson, setEditingLesson] = useState<{ moduleId: string; lesson: Lesson } | null>(null)

  const addModule = () => {
    const newModule: Module = {
      id: Date.now().toString(),
      title: "New Module",
      description: "",
      lessons: [],
      isExpanded: true,
    }
    setModules([...modules, newModule])
  }

  const updateModule = (moduleId: string, updates: Partial<Module>) => {
    setModules(modules.map((module) => (module.id === moduleId ? { ...module, ...updates } : module)))
  }

  const deleteModule = (moduleId: string) => {
    setModules(modules.filter((module) => module.id !== moduleId))
  }

  const addLesson = (moduleId: string, contentType: Lesson["content_type"]) => {
    const newLesson: Lesson = {
      id: Date.now().toString(),
      title: "New Lesson",
      content_type: contentType,
      duration_minutes: 0,
      content: {},
    }

    setModules(
      modules.map((module) =>
        module.id === moduleId ? { ...module, lessons: [...module.lessons, newLesson] } : module,
      ),
    )
  }

  const updateLesson = (moduleId: string, lessonId: string, updates: Partial<Lesson>) => {
    setModules(
      modules.map((module) =>
        module.id === moduleId
          ? {
              ...module,
              lessons: module.lessons.map((lesson) => (lesson.id === lessonId ? { ...lesson, ...updates } : lesson)),
            }
          : module,
      ),
    )
  }

  const deleteLesson = (moduleId: string, lessonId: string) => {
    setModules(
      modules.map((module) =>
        module.id === moduleId
          ? { ...module, lessons: module.lessons.filter((lesson) => lesson.id !== lessonId) }
          : module,
      ),
    )
  }

  const getContentTypeIcon = (type: string) => {
    switch (type) {
      case "text":
        return <FileText className="w-4 h-4" />
      case "video":
        return <Video className="w-4 h-4" />
      case "quiz":
        return <ClipboardList className="w-4 h-4" />
      case "file":
        return <Upload className="w-4 h-4" />
      default:
        return <FileText className="w-4 h-4" />
    }
  }

  const getContentTypeColor = (type: string) => {
    switch (type) {
      case "text":
        return "bg-blue-100 text-blue-800"
      case "video":
        return "bg-purple-100 text-purple-800"
      case "quiz":
        return "bg-green-100 text-green-800"
      case "file":
        return "bg-orange-100 text-orange-800"
      default:
        return "bg-gray-100 text-gray-800"
    }
  }

  return (
    <div className="space-y-6">
      <Card>
        <CardHeader>
          <div className="flex items-center justify-between">
            <div>
              <CardTitle>Course Content</CardTitle>
              <CardDescription>Organize your course into modules and lessons</CardDescription>
            </div>
            <Button onClick={addModule}>
              <Plus className="w-4 h-4 mr-2" />
              Add Module
            </Button>
          </div>
        </CardHeader>
        <CardContent>
          {modules.length === 0 ? (
            <div className="text-center py-12 border-2 border-dashed border-gray-300 rounded-lg">
              <div className="w-16 h-16 bg-gray-100 rounded-full flex items-center justify-center mx-auto mb-4">
                <Plus className="w-8 h-8 text-gray-400" />
              </div>
              <h3 className="text-lg font-medium text-gray-900 mb-2">No modules yet</h3>
              <p className="text-gray-600 mb-4">Start building your course by adding your first module</p>
              <Button onClick={addModule}>
                <Plus className="w-4 h-4 mr-2" />
                Add Your First Module
              </Button>
            </div>
          ) : (
            <div className="space-y-4">
              {modules.map((module, moduleIndex) => (
                <Card key={module.id} className="border-l-4 border-l-blue-500">
                  <CardHeader className="pb-3">
                    <div className="flex items-center gap-3">
                      <GripVertical className="w-5 h-5 text-gray-400 cursor-move" />
                      <Button
                        variant="ghost"
                        size="sm"
                        onClick={() => updateModule(module.id, { isExpanded: !module.isExpanded })}
                      >
                        {module.isExpanded ? <ChevronDown className="w-4 h-4" /> : <ChevronRight className="w-4 h-4" />}
                      </Button>
                      <div className="flex-1">
                        <Input
                          value={module.title}
                          onChange={(e) => updateModule(module.id, { title: e.target.value })}
                          className="font-semibold text-lg border-none p-0 h-auto focus-visible:ring-0"
                          placeholder="Module title"
                        />
                        <Textarea
                          value={module.description}
                          onChange={(e) => updateModule(module.id, { description: e.target.value })}
                          placeholder="Module description (optional)"
                          className="mt-2 border-none p-0 resize-none focus-visible:ring-0"
                          rows={2}
                        />
                      </div>
                      <Badge variant="outline">Module {moduleIndex + 1}</Badge>
                      <Button variant="ghost" size="sm" onClick={() => deleteModule(module.id)}>
                        <Trash2 className="w-4 h-4 text-red-500" />
                      </Button>
                    </div>
                  </CardHeader>

                  {module.isExpanded && (
                    <CardContent className="pt-0">
                      <div className="space-y-3">
                        {module.lessons.map((lesson, lessonIndex) => (
                          <div key={lesson.id} className="flex items-center gap-3 p-3 bg-gray-50 rounded-lg">
                            <GripVertical className="w-4 h-4 text-gray-400 cursor-move" />
                            <div className={`p-2 rounded ${getContentTypeColor(lesson.content_type)}`}>
                              {getContentTypeIcon(lesson.content_type)}
                            </div>
                            <div className="flex-1">
                              <Input
                                value={lesson.title}
                                onChange={(e) => updateLesson(module.id, lesson.id, { title: e.target.value })}
                                className="font-medium border-none p-0 h-auto bg-transparent focus-visible:ring-0"
                                placeholder="Lesson title"
                              />
                              <p className="text-sm text-gray-500 mt-1">
                                {lesson.content_type} • {lesson.duration_minutes} min
                              </p>
                            </div>
                            <Button
                              variant="ghost"
                              size="sm"
                              onClick={() => setEditingLesson({ moduleId: module.id, lesson })}
                            >
                              <Edit className="w-4 h-4" />
                            </Button>
                            <Button variant="ghost" size="sm" onClick={() => deleteLesson(module.id, lesson.id)}>
                              <Trash2 className="w-4 h-4 text-red-500" />
                            </Button>
                          </div>
                        ))}

                        <div className="flex gap-2 pt-2">
                          <Button
                            variant="outline"
                            size="sm"
                            onClick={() => addLesson(module.id, "text")}
                            className="flex-1"
                          >
                            <FileText className="w-4 h-4 mr-2" />
                            Text Lesson
                          </Button>
                          <Button
                            variant="outline"
                            size="sm"
                            onClick={() => addLesson(module.id, "video")}
                            className="flex-1"
                          >
                            <Video className="w-4 h-4 mr-2" />
                            Video Lesson
                          </Button>
                          <Button
                            variant="outline"
                            size="sm"
                            onClick={() => addLesson(module.id, "quiz")}
                            className="flex-1"
                          >
                            <ClipboardList className="w-4 h-4 mr-2" />
                            Quiz
                          </Button>
                          <Button
                            variant="outline"
                            size="sm"
                            onClick={() => addLesson(module.id, "file")}
                            className="flex-1"
                          >
                            <Upload className="w-4 h-4 mr-2" />
                            File/Resource
                          </Button>
                        </div>
                      </div>
                    </CardContent>
                  )}
                </Card>
              ))}
            </div>
          )}
        </CardContent>
      </Card>

      {/* Lesson Editor Modal */}
      {editingLesson && (
        <LessonEditor
          lesson={editingLesson.lesson}
          onSave={(updatedLesson) => {
            updateLesson(editingLesson.moduleId, editingLesson.lesson.id, updatedLesson)
            setEditingLesson(null)
          }}
          onClose={() => setEditingLesson(null)}
        />
      )}
    </div>
  )
}
