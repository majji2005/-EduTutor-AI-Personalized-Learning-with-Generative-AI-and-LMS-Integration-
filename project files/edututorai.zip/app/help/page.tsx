import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Input } from "@/components/ui/input"
import { Button } from "@/components/ui/button"
import { Search, PlayCircle, User, BookOpen, ClipboardList, Settings } from "lucide-react"
import Link from "next/link"

const categories = [
  {
    id: 1,
    name: "Getting Started",
    description: "Basic setup and first steps",
    icon: PlayCircle,
    articleCount: 8,
    color: "bg-blue-100 text-blue-600",
  },
  {
    id: 2,
    name: "Account Management",
    description: "Managing your profile and settings",
    icon: User,
    articleCount: 12,
    color: "bg-green-100 text-green-600",
  },
  {
    id: 3,
    name: "Courses & Learning",
    description: "Everything about courses and learning paths",
    icon: BookOpen,
    articleCount: 15,
    color: "bg-purple-100 text-purple-600",
  },
  {
    id: 4,
    name: "Quizzes & Assessments",
    description: "Quiz creation and taking assessments",
    icon: ClipboardList,
    articleCount: 10,
    color: "bg-orange-100 text-orange-600",
  },
  {
    id: 5,
    name: "Google Classroom",
    description: "Integration with Google Classroom",
    icon: Settings,
    articleCount: 6,
    color: "bg-red-100 text-red-600",
  },
  {
    id: 6,
    name: "Technical Support",
    description: "Technical issues and troubleshooting",
    icon: Settings,
    articleCount: 9,
    color: "bg-gray-100 text-gray-600",
  },
]

export default function HelpCenter() {
  return (
    <div className="min-h-screen bg-gray-50">
      {/* Header */}
      <div className="bg-white border-b">
        <div className="max-w-4xl mx-auto px-4 py-8 text-center">
          <h1 className="text-4xl font-bold text-gray-900 mb-4">Help Center</h1>
          <p className="text-xl text-gray-600 mb-8">Find answers to your questions and get the help you need</p>

          {/* Search */}
          <div className="relative max-w-2xl mx-auto">
            <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400 w-5 h-5" />
            <Input placeholder="Search for help articles..." className="pl-10 pr-4 py-3 text-lg" />
            <Button className="absolute right-2 top-1/2 transform -translate-y-1/2">Search</Button>
          </div>
        </div>
      </div>

      {/* Categories */}
      <div className="max-w-6xl mx-auto px-4 py-12">
        <h2 className="text-2xl font-bold text-gray-900 mb-8">Browse by Category</h2>

        <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-6 mb-12">
          {categories.map((category) => (
            <Link key={category.id} href={`/help/category/${category.id}`}>
              <Card className="hover:shadow-md transition-shadow cursor-pointer h-full">
                <CardHeader>
                  <div className={`w-12 h-12 rounded-lg ${category.color} flex items-center justify-center mb-4`}>
                    <category.icon className="w-6 h-6" />
                  </div>
                  <CardTitle className="text-lg">{category.name}</CardTitle>
                  <CardDescription>{category.description}</CardDescription>
                </CardHeader>
                <CardContent>
                  <p className="text-sm text-gray-500">{category.articleCount} articles</p>
                </CardContent>
              </Card>
            </Link>
          ))}
        </div>

        {/* Quick Actions */}
        <div className="bg-white rounded-lg p-8 text-center">
          <h3 className="text-xl font-semibold text-gray-900 mb-4">Still need help?</h3>
          <p className="text-gray-600 mb-6">Can't find what you're looking for? Our support team is here to help.</p>
          <div className="flex flex-col sm:flex-row gap-4 justify-center">
            <Button asChild>
              <Link href="/help/contact">Contact Support</Link>
            </Button>
            <Button variant="outline" asChild>
              <Link href="/help/tickets">View My Tickets</Link>
            </Button>
          </div>
        </div>
      </div>
    </div>
  )
}
