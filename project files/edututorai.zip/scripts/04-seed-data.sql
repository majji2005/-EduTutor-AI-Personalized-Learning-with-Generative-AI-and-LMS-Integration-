-- Insert sample educator profiles (these would be created through signup)
INSERT INTO public.profiles (id, email, full_name, role) VALUES
  ('550e8400-e29b-41d4-a716-446655440001', 'educator1@example.com', 'Dr. Sarah Johnson', 'educator'),
  ('550e8400-e29b-41d4-a716-446655440002', 'educator2@example.com', 'Prof. Michael Chen', 'educator');

-- Insert sample student profiles
INSERT INTO public.profiles (id, email, full_name, role) VALUES
  ('550e8400-e29b-41d4-a716-446655440003', 'student1@example.com', 'Alice Smith', 'student'),
  ('550e8400-e29b-41d4-a716-446655440004', 'student2@example.com', 'Bob Wilson', 'student'),
  ('550e8400-e29b-41d4-a716-446655440005', 'student3@example.com', 'Carol Davis', 'student');

-- Insert sample courses
INSERT INTO public.courses (id, title, description, subject, educator_id) VALUES
  ('650e8400-e29b-41d4-a716-446655440001', 'Advanced Mathematics', 'Comprehensive algebra and calculus course', 'Mathematics', '550e8400-e29b-41d4-a716-446655440001'),
  ('650e8400-e29b-41d4-a716-446655440002', 'Physics Fundamentals', 'Introduction to mechanics and thermodynamics', 'Physics', '550e8400-e29b-41d4-a716-446655440001'),
  ('650e8400-e29b-41d4-a716-446655440003', 'Chemistry Lab', 'Hands-on organic chemistry experiments', 'Chemistry', '550e8400-e29b-41d4-a716-446655440002');

-- Insert sample course enrollments
INSERT INTO public.course_enrollments (course_id, student_id, progress) VALUES
  ('650e8400-e29b-41d4-a716-446655440001', '550e8400-e29b-41d4-a716-446655440003', 75),
  ('650e8400-e29b-41d4-a716-446655440002', '550e8400-e29b-41d4-a716-446655440003', 60),
  ('650e8400-e29b-41d4-a716-446655440003', '550e8400-e29b-41d4-a716-446655440003', 90),
  ('650e8400-e29b-41d4-a716-446655440001', '550e8400-e29b-41d4-a716-446655440004', 45),
  ('650e8400-e29b-41d4-a716-446655440002', '550e8400-e29b-41d4-a716-446655440004', 30);

-- Insert sample quizzes
INSERT INTO public.quizzes (id, title, description, course_id, difficulty, time_limit, created_by) VALUES
  ('750e8400-e29b-41d4-a716-446655440001', 'Algebra Practice Quiz', 'Test your algebra skills', '650e8400-e29b-41d4-a716-446655440001', 'medium', 15, '550e8400-e29b-41d4-a716-446655440001'),
  ('750e8400-e29b-41d4-a716-446655440002', 'Physics Problem Set', 'Mechanics problems', '650e8400-e29b-41d4-a716-446655440002', 'hard', 20, '550e8400-e29b-41d4-a716-446655440001'),
  ('750e8400-e29b-41d4-a716-446655440003', 'Chemistry Review', 'Organic chemistry concepts', '650e8400-e29b-41d4-a716-446655440003', 'easy', 18, '550e8400-e29b-41d4-a716-446655440002');
