"use client"

import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { Button } from "@/components/ui/button"
import { Clock, Users, Star, Play, FileText, Video, ClipboardList, Upload } from "lucide-react"

interface CoursePreviewProps {
  courseData: any
}

export function CoursePreview({ courseData }: CoursePreviewProps) {
  const getContentTypeIcon = (type: string) => {
    switch (type) {
      case "text":
        return <FileText className="w-4 h-4" />
      case "video":
        return <Video className="w-4 h-4" />
      case "quiz":
        return <ClipboardList className="w-4 h-4" />
      case "file":
        return <Upload className="w-4 h-4" />
      default:
        return <FileText className="w-4 h-4" />
    }
  }

  return (
    <div className="max-w-4xl mx-auto">
      <div className="grid lg:grid-cols-3 gap-8">
        {/* Course Info */}
        <div className="lg:col-span-2">
          <div className="space-y-6">
            {/* Course Header */}
            <div>
              <div className="flex items-center gap-2 mb-4">
                <Badge variant="secondary">{courseData.subject}</Badge>
                <Badge variant="outline">{courseData.difficulty_level}</Badge>
              </div>
              <h1 className="text-3xl font-bold text-gray-900 mb-4">{courseData.title || "Course Title"}</h1>
              <p className="text-lg text-gray-600 mb-6">
                {courseData.description || "Course description will appear here..."}
              </p>

              <div className="flex items-center gap-6 text-sm text-gray-600">
                <div className="flex items-center gap-1">
                  <Clock className="w-4 h-4" />
                  {courseData.estimated_duration} hours
                </div>
                <div className="flex items-center gap-1">
                  <Users className="w-4 h-4" />0 students
                </div>
                <div className="flex items-center gap-1">
                  <Star className="w-4 h-4" />
                  New course
                </div>
              </div>
            </div>

            {/* Course Content Preview */}
            <Card>
              <CardHeader>
                <CardTitle>Course Content</CardTitle>
                <CardDescription>What you'll learn in this course</CardDescription>
              </CardHeader>
              <CardContent>
                <div className="space-y-4">
                  {/* Mock modules for preview */}
                  <div className="border rounded-lg p-4">
                    <div className="flex items-center justify-between mb-3">
                      <h3 className="font-semibold">Module 1: Introduction</h3>
                      <Badge variant="outline">3 lessons</Badge>
                    </div>
                    <div className="space-y-2">
                      <div className="flex items-center gap-3 text-sm">
                        <Play className="w-4 h-4 text-gray-400" />
                        <FileText className="w-4 h-4" />
                        <span>Welcome to the course</span>
                        <span className="text-gray-500 ml-auto">5 min</span>
                      </div>
                      <div className="flex items-center gap-3 text-sm">
                        <Play className="w-4 h-4 text-gray-400" />
                        <Video className="w-4 h-4" />
                        <span>Course overview video</span>
                        <span className="text-gray-500 ml-auto">10 min</span>
                      </div>
                      <div className="flex items-center gap-3 text-sm">
                        <Play className="w-4 h-4 text-gray-400" />
                        <ClipboardList className="w-4 h-4" />
                        <span>Knowledge check quiz</span>
                        <span className="text-gray-500 ml-auto">3 min</span>
                      </div>
                    </div>
                  </div>

                  <div className="text-center py-8 text-gray-500">
                    <p>Add modules and lessons to see them in the preview</p>
                  </div>
                </div>
              </CardContent>
            </Card>

            {/* Learning Objectives */}
            <Card>
              <CardHeader>
                <CardTitle>What You'll Learn</CardTitle>
              </CardHeader>
              <CardContent>
                <ul className="space-y-2">
                  <li className="flex items-start gap-2">
                    <div className="w-2 h-2 bg-blue-600 rounded-full mt-2"></div>
                    <span>Master the fundamentals of {courseData.subject}</span>
                  </li>
                  <li className="flex items-start gap-2">
                    <div className="w-2 h-2 bg-blue-600 rounded-full mt-2"></div>
                    <span>Apply concepts through hands-on exercises</span>
                  </li>
                  <li className="flex items-start gap-2">
                    <div className="w-2 h-2 bg-blue-600 rounded-full mt-2"></div>
                    <span>Build confidence through practice quizzes</span>
                  </li>
                </ul>
              </CardContent>
            </Card>
          </div>
        </div>

        {/* Course Sidebar */}
        <div className="lg:col-span-1">
          <Card className="sticky top-6">
            <CardHeader>
              <div className="aspect-video bg-gray-200 rounded-lg flex items-center justify-center mb-4">
                {courseData.thumbnail_url ? (
                  <img
                    src={courseData.thumbnail_url || "/placeholder.svg"}
                    alt="Course thumbnail"
                    className="w-full h-full object-cover rounded-lg"
                  />
                ) : (
                  <div className="text-gray-500">
                    <Play className="w-12 h-12 mx-auto mb-2" />
                    <p className="text-sm">Course Preview</p>
                  </div>
                )}
              </div>
              <div className="text-center">
                <div className="text-3xl font-bold text-gray-900 mb-2">
                  {courseData.price > 0 ? `$${courseData.price}` : "Free"}
                </div>
                <Button className="w-full mb-4">Enroll Now</Button>
                <p className="text-sm text-gray-600">30-day money-back guarantee</p>
              </div>
            </CardHeader>
            <CardContent>
              <div className="space-y-4">
                <div>
                  <h4 className="font-semibold mb-2">This course includes:</h4>
                  <ul className="space-y-2 text-sm">
                    <li className="flex items-center gap-2">
                      <Clock className="w-4 h-4" />
                      {courseData.estimated_duration} hours of content
                    </li>
                    <li className="flex items-center gap-2">
                      <Video className="w-4 h-4" />
                      Video lessons
                    </li>
                    <li className="flex items-center gap-2">
                      <ClipboardList className="w-4 h-4" />
                      Interactive quizzes
                    </li>
                    <li className="flex items-center gap-2">
                      <Upload className="w-4 h-4" />
                      Downloadable resources
                    </li>
                  </ul>
                </div>

                {courseData.tags.length > 0 && (
                  <div>
                    <h4 className="font-semibold mb-2">Tags:</h4>
                    <div className="flex flex-wrap gap-2">
                      {courseData.tags.map((tag: string) => (
                        <Badge key={tag} variant="secondary" className="text-xs">
                          {tag}
                        </Badge>
                      ))}
                    </div>
                  </div>
                )}
              </div>
            </CardContent>
          </Card>
        </div>
      </div>
    </div>
  )
}
