import { type NextRequest, NextResponse } from "next/server"
import { supabaseServer } from "@/lib/supabase-server"

export async function POST(request: NextRequest) {
  try {
    const courseData = await request.json()

    // Get user from auth (you'd implement proper auth here)
    const educatorId = "educator-id-placeholder"

    const { data: course, error } = await supabaseServer
      .from("courses")
      .insert({
        ...courseData,
        educator_id: educatorId,
      })
      .select()
      .single()

    if (error) {
      return NextResponse.json({ error: "Failed to create course" }, { status: 500 })
    }

    return NextResponse.json({ success: true, course })
  } catch (error) {
    return NextResponse.json({ error: "Server error" }, { status: 500 })
  }
}

export async function GET(request: NextRequest) {
  try {
    const { searchParams } = new URL(request.url)
    const educatorId = searchParams.get("educatorId")

    const { data: courses, error } = await supabaseServer
      .from("courses")
      .select(`
        *,
        course_modules (
          id,
          title,
          order_index,
          lessons (
            id,
            title,
            content_type,
            duration_minutes
          )
        )
      `)
      .eq("educator_id", educatorId)
      .order("created_at", { ascending: false })

    if (error) {
      return NextResponse.json({ error: "Failed to fetch courses" }, { status: 500 })
    }

    return NextResponse.json({ courses })
  } catch (error) {
    return NextResponse.json({ error: "Server error" }, { status: 500 })
  }
}
