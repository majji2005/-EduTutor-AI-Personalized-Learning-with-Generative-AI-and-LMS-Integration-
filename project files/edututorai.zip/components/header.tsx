import Link from "next/link"
import { Button } from "@/components/ui/button"
import { GraduationCap } from "lucide-react"

export function Header() {
  return (
    <header className="w-full px-4 py-4 flex items-center justify-between max-w-7xl mx-auto">
      <Link href="/" className="flex items-center gap-2">
        <div className="w-8 h-8 bg-blue-600 rounded-full flex items-center justify-center">
          <GraduationCap className="w-5 h-5 text-white" />
        </div>
        <span className="text-xl font-semibold text-gray-900">Edututor AI</span>
      </Link>

      <div className="flex items-center gap-3">
        <Button variant="ghost" asChild>
          <Link href="/student/login">Student Login</Link>
        </Button>
        <Button variant="default" className="bg-gray-900 hover:bg-gray-800" asChild>
          <Link href="/educator/login">Educator Login</Link>
        </Button>
      </div>
    </header>
  )
}
