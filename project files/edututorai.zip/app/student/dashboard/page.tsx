"use client"

import { useEffect, useState } from "react"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Progress } from "@/components/ui/progress"
import { BookOpen, Clock, Trophy, Target, LogOut } from "lucide-react"
import { supabase } from "@/lib/supabase"
import { useRouter } from "next/navigation"

interface Course {
  id: string
  title: string
  subject: string
  progress: number
}

interface Quiz {
  id: string
  title: string
  description: string
  time_limit: number
  course: {
    title: string
  }
}

interface DashboardStats {
  coursesEnrolled: number
  hoursStudied: number
  quizzesCompleted: number
  averageScore: number
}

export default function StudentDashboard() {
  const [user, setUser] = useState<any>(null)
  const [courses, setCourses] = useState<Course[]>([])
  const [availableQuizzes, setAvailableQuizzes] = useState<Quiz[]>([])
  const [stats, setStats] = useState<DashboardStats>({
    coursesEnrolled: 0,
    hoursStudied: 0,
    quizzesCompleted: 0,
    averageScore: 0,
  })
  const [loading, setLoading] = useState(true)
  const router = useRouter()

  useEffect(() => {
    checkUser()
  }, [])

  const checkUser = async () => {
    const {
      data: { user },
    } = await supabase.auth.getUser()

    if (!user) {
      router.push("/student/login")
      return
    }

    setUser(user)
    await loadDashboardData(user.id)
  }

  const loadDashboardData = async (userId: string) => {
    try {
      // Load enrolled courses
      const { data: enrollments } = await supabase
        .from("course_enrollments")
        .select(`
          progress,
          courses (
            id,
            title,
            subject
          )
        `)
        .eq("student_id", userId)

      const coursesData =
        enrollments?.map((enrollment) => ({
          id: enrollment.courses.id,
          title: enrollment.courses.title,
          subject: enrollment.courses.subject,
          progress: enrollment.progress,
        })) || []

      setCourses(coursesData)

      // Load available quizzes
      const { data: quizzes } = await supabase
        .from("quizzes")
        .select(`
          id,
          title,
          description,
          time_limit,
          courses (
            title
          )
        `)
        .limit(3)

      setAvailableQuizzes(quizzes || [])

      // Load analytics/stats
      const { data: analytics } = await supabase.from("student_analytics").select("*").eq("student_id", userId)

      const totalQuizzes = analytics?.reduce((sum, record) => sum + record.total_quizzes_taken, 0) || 0
      const avgScore =
        analytics?.length > 0 ? analytics.reduce((sum, record) => sum + record.average_score, 0) / analytics.length : 0

      setStats({
        coursesEnrolled: coursesData.length,
        hoursStudied: analytics?.reduce((sum, record) => sum + record.total_study_time, 0) || 47,
        quizzesCompleted: totalQuizzes,
        averageScore: Math.round(avgScore),
      })
    } catch (error) {
      console.error("Error loading dashboard data:", error)
    } finally {
      setLoading(false)
    }
  }

  const handleSignOut = async () => {
    await supabase.auth.signOut()
    router.push("/")
  }

  if (loading) {
    return (
      <div className="min-h-screen bg-gray-50 flex items-center justify-center">
        <div className="text-center">
          <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-blue-600 mx-auto mb-4"></div>
          <p className="text-gray-600">Loading your dashboard...</p>
        </div>
      </div>
    )
  }

  return (
    <div className="min-h-screen bg-gray-50">
      <div className="bg-white border-b">
        <div className="max-w-7xl mx-auto px-4 py-4 flex justify-between items-center">
          <div>
            <h1 className="text-2xl font-bold text-gray-900">Student Dashboard</h1>
            <p className="text-gray-600">Welcome back, {user?.user_metadata?.full_name || "Student"}!</p>
          </div>
          <Button variant="outline" onClick={handleSignOut}>
            <LogOut className="w-4 h-4 mr-2" />
            Sign Out
          </Button>
        </div>
      </div>

      <div className="max-w-7xl mx-auto px-4 py-8">
        <div className="grid md:grid-cols-4 gap-6 mb-8">
          <Card>
            <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
              <CardTitle className="text-sm font-medium">Courses Enrolled</CardTitle>
              <BookOpen className="h-4 w-4 text-muted-foreground" />
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold">{stats.coursesEnrolled}</div>
            </CardContent>
          </Card>
          <Card>
            <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
              <CardTitle className="text-sm font-medium">Hours Studied</CardTitle>
              <Clock className="h-4 w-4 text-muted-foreground" />
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold">{Math.round(stats.hoursStudied / 60)}</div>
            </CardContent>
          </Card>
          <Card>
            <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
              <CardTitle className="text-sm font-medium">Quizzes Completed</CardTitle>
              <Target className="h-4 w-4 text-muted-foreground" />
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold">{stats.quizzesCompleted}</div>
            </CardContent>
          </Card>
          <Card>
            <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
              <CardTitle className="text-sm font-medium">Average Score</CardTitle>
              <Trophy className="h-4 w-4 text-muted-foreground" />
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold">{stats.averageScore}%</div>
            </CardContent>
          </Card>
        </div>

        <div className="grid md:grid-cols-2 gap-6">
          <Card>
            <CardHeader>
              <CardTitle>Current Courses</CardTitle>
              <CardDescription>Your active learning paths</CardDescription>
            </CardHeader>
            <CardContent className="space-y-4">
              {courses.length > 0 ? (
                courses.map((course) => (
                  <div key={course.id} className="space-y-2">
                    <div className="flex justify-between">
                      <span className="font-medium">{course.title}</span>
                      <span className="text-sm text-gray-500">{course.progress}%</span>
                    </div>
                    <Progress value={course.progress} />
                  </div>
                ))
              ) : (
                <p className="text-gray-500">No courses enrolled yet. Start learning today!</p>
              )}
            </CardContent>
          </Card>

          <Card>
            <CardHeader>
              <CardTitle>AI-Generated Quizzes</CardTitle>
              <CardDescription>Personalized practice sessions</CardDescription>
            </CardHeader>
            <CardContent className="space-y-4">
              {availableQuizzes.length > 0 ? (
                availableQuizzes.map((quiz) => (
                  <div key={quiz.id} className="flex items-center justify-between p-3 border rounded-lg">
                    <div>
                      <p className="font-medium">{quiz.title}</p>
                      <p className="text-sm text-gray-500">
                        {quiz.courses?.title} • {quiz.time_limit} min
                      </p>
                    </div>
                    <Button size="sm">Start</Button>
                  </div>
                ))
              ) : (
                <p className="text-gray-500">No quizzes available at the moment.</p>
              )}
            </CardContent>
          </Card>
        </div>
      </div>
    </div>
  )
}
