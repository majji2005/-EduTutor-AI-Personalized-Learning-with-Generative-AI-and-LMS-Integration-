import { NextResponse } from "next/server"
import { GoogleClassroomService } from "@/lib/google-classroom"

export async function GET() {
  try {
    const authUrl = GoogleClassroomService.getAuthUrl()
    return NextResponse.json({ authUrl })
  } catch (error) {
    return NextResponse.json({ error: "Failed to generate auth URL" }, { status: 500 })
  }
}
