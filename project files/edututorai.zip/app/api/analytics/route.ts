import { type NextRequest, NextResponse } from "next/server"
import { supabaseServer } from "@/lib/supabase-server"

export async function GET(request: NextRequest) {
  try {
    const { searchParams } = new URL(request.url)
    const educatorId = searchParams.get("educatorId")

    if (!educatorId) {
      return NextResponse.json({ success: false, message: "Educator ID required" }, { status: 400 })
    }

    // Get educator's courses
    const { data: courses } = await supabaseServer.from("courses").select("id").eq("educator_id", educatorId)

    const courseIds = courses?.map((c) => c.id) || []

    // Get analytics data
    const { data: analytics } = await supabaseServer.from("student_analytics").select("*").in("course_id", courseIds)

    // Get total enrollments
    const { count: totalStudents } = await supabaseServer
      .from("course_enrollments")
      .select("*", { count: "exact", head: true })
      .in("course_id", courseIds)

    // Get quiz count
    const { count: quizzesGenerated } = await supabaseServer
      .from("quizzes")
      .select("*", { count: "exact", head: true })
      .eq("created_by", educatorId)

    const averagePerformance =
      analytics?.length > 0 ? analytics.reduce((sum, record) => sum + record.average_score, 0) / analytics.length : 0

    return NextResponse.json({
      success: true,
      data: {
        totalStudents: totalStudents || 0,
        activeCourses: courses?.length || 0,
        quizzesGenerated: quizzesGenerated || 0,
        averagePerformance: Math.round(averagePerformance),
        recentActivity: analytics?.slice(-5) || [],
      },
    })
  } catch (error) {
    return NextResponse.json({ success: false, message: "Failed to fetch analytics" }, { status: 500 })
  }
}
