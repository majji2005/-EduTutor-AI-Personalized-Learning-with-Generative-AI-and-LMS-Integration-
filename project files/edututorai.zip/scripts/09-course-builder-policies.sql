-- Enable RLS on new tables
ALTER TABLE public.course_modules ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.lessons ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.course_materials ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.lesson_progress ENABLE ROW LEVEL SECURITY;

-- Course modules policies
CREATE POLICY "Educators can manage own course modules" ON public.course_modules
  FOR ALL USING (EXISTS (
    SELECT 1 FROM public.courses 
    WHERE id = course_id AND educator_id = auth.uid()
  ));

CREATE POLICY "Students can view published modules" ON public.course_modules
  FOR SELECT USING (
    is_published = true AND EXISTS (
      SELECT 1 FROM public.course_enrollments ce
      JOIN public.courses c ON c.id = ce.course_id
      WHERE c.id = course_id AND ce.student_id = auth.uid()
    )
  );

-- Lessons policies
CREATE POLICY "Educators can manage own lessons" ON public.lessons
  FOR ALL USING (EXISTS (
    SELECT 1 FROM public.course_modules cm
    JOIN public.courses c ON c.id = cm.course_id
    WHERE cm.id = module_id AND c.educator_id = auth.uid()
  ));

CREATE POLICY "Students can view published lessons" ON public.lessons
  FOR SELECT USING (
    is_published = true AND EXISTS (
      SELECT 1 FROM public.course_modules cm
      JOIN public.courses c ON c.id = cm.course_id
      JOIN public.course_enrollments ce ON ce.course_id = c.id
      WHERE cm.id = module_id AND ce.student_id = auth.uid()
    )
  );

-- Course materials policies
CREATE POLICY "Educators can manage own course materials" ON public.course_materials
  FOR ALL USING (EXISTS (
    SELECT 1 FROM public.courses 
    WHERE id = course_id AND educator_id = auth.uid()
  ));

-- Lesson progress policies
CREATE POLICY "Students can manage own progress" ON public.lesson_progress
  FOR ALL USING (auth.uid() = student_id);

CREATE POLICY "Educators can view student progress" ON public.lesson_progress
  FOR SELECT USING (EXISTS (
    SELECT 1 FROM public.lessons l
    JOIN public.course_modules cm ON cm.id = l.module_id
    JOIN public.courses c ON c.id = cm.course_id
    WHERE l.id = lesson_id AND c.educator_id = auth.uid()
  ));
