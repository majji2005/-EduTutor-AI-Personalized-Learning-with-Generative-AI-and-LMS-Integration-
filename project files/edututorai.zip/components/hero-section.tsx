import { Button } from "@/components/ui/button"
import { Badge } from "@/components/ui/badge"
import Link from "next/link"
import { ArrowRight } from "lucide-react"

export function HeroSection() {
  return (
    <section className="px-4 py-20 text-center max-w-4xl mx-auto">
      <Badge variant="secondary" className="mb-8 bg-blue-50 text-blue-700 border-blue-200">
        🔵 Powered by AI & Machine Learning
      </Badge>

      <h1 className="text-5xl md:text-6xl font-bold mb-6 leading-tight">
        <span className="text-blue-600">Personalized Learning</span>
        <br />
        <span className="text-gray-900">with AI Excellence</span>
      </h1>

      <p className="text-xl text-gray-600 mb-12 max-w-3xl mx-auto leading-relaxed">
        Revolutionary AI-powered education platform that adapts to every student's unique learning style. Generate
        dynamic quizzes, track progress, and integrate seamlessly with Google Classroom.
      </p>

      <div className="flex flex-col sm:flex-row gap-4 justify-center items-center">
        <Button size="lg" className="bg-blue-600 hover:bg-blue-700 px-8" asChild>
          <Link href="/student/dashboard">
            Start Learning
            <ArrowRight className="ml-2 w-4 h-4" />
          </Link>
        </Button>
        <Button size="lg" variant="outline" className="px-8" asChild>
          <Link href="/educator/dashboard">Educator Dashboard</Link>
        </Button>
      </div>
    </section>
  )
}
