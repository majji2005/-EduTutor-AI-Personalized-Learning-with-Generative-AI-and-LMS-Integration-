import { type NextRequest, NextResponse } from "next/server"
import { supabaseServer } from "@/lib/supabase-server"

export async function POST(request: NextRequest) {
  try {
    const { subject, priority, description } = await request.json()

    // In a real app, you'd get the user ID from the auth token
    // For now, we'll use a placeholder
    const userId = "user-id-placeholder"

    const { data, error } = await supabaseServer
      .from("support_tickets")
      .insert({
        user_id: userId,
        subject,
        priority,
        description,
        status: "open",
      })
      .select()
      .single()

    if (error) {
      return NextResponse.json({ error: "Failed to create ticket" }, { status: 500 })
    }

    return NextResponse.json({ success: true, ticket: data })
  } catch (error) {
    return NextResponse.json({ error: "Server error" }, { status: 500 })
  }
}

export async function GET(request: NextRequest) {
  try {
    const { searchParams } = new URL(request.url)
    const userId = searchParams.get("userId")

    const { data: tickets, error } = await supabaseServer
      .from("support_tickets")
      .select("*")
      .eq("user_id", userId)
      .order("created_at", { ascending: false })

    if (error) {
      return NextResponse.json({ error: "Failed to fetch tickets" }, { status: 500 })
    }

    return NextResponse.json({ tickets })
  } catch (error) {
    return NextResponse.json({ error: "Server error" }, { status: 500 })
  }
}
