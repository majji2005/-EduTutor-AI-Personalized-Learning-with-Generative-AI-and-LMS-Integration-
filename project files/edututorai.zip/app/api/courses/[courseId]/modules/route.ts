import { type NextRequest, NextResponse } from "next/server"
import { supabaseServer } from "@/lib/supabase-server"

export async function POST(request: NextRequest, { params }: { params: { courseId: string } }) {
  try {
    const moduleData = await request.json()

    const { data: module, error } = await supabaseServer
      .from("course_modules")
      .insert({
        ...moduleData,
        course_id: params.courseId,
      })
      .select()
      .single()

    if (error) {
      return NextResponse.json({ error: "Failed to create module" }, { status: 500 })
    }

    return NextResponse.json({ success: true, module })
  } catch (error) {
    return NextResponse.json({ error: "Server error" }, { status: 500 })
  }
}

export async function GET(request: NextRequest, { params }: { params: { courseId: string } }) {
  try {
    const { data: modules, error } = await supabaseServer
      .from("course_modules")
      .select(`
        *,
        lessons (
          id,
          title,
          content_type,
          duration_minutes,
          order_index
        )
      `)
      .eq("course_id", params.courseId)
      .order("order_index", { ascending: true })

    if (error) {
      return NextResponse.json({ error: "Failed to fetch modules" }, { status: 500 })
    }

    return NextResponse.json({ modules })
  } catch (error) {
    return NextResponse.json({ error: "Server error" }, { status: 500 })
  }
}
