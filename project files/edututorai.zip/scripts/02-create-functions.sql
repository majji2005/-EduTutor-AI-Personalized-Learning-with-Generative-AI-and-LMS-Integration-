-- Function to handle user profile creation
CREATE OR REPLACE FUNCTION public.handle_new_user()
RETURNS TRIGGER AS $$
BEGIN
  INSERT INTO public.profiles (id, email, full_name)
  VALUES (NEW.id, NEW.email, NEW.raw_user_meta_data->>'full_name');
  RETURN NEW;
END;
$$ LANGUAGE plpgsql SECURITY DEFINER;

-- Trigger to automatically create profile on user signup
CREATE OR REPLACE TRIGGER on_auth_user_created
  AFTER INSERT ON auth.users
  FOR EACH ROW EXECUTE FUNCTION public.handle_new_user();

-- Function to update analytics after quiz completion
CREATE OR REPLACE FUNCTION public.update_student_analytics()
RETURNS TRIGGER AS $$
BEGIN
  -- Update or insert analytics record
  INSERT INTO public.student_analytics (
    student_id, 
    course_id, 
    total_quizzes_taken, 
    average_score,
    last_activity
  )
  SELECT 
    NEW.student_id,
    q.course_id,
    COUNT(qa.id),
    AVG(qa.percentage),
    NOW()
  FROM public.quizzes q
  JOIN public.quiz_attempts qa ON qa.quiz_id = q.id
  WHERE qa.student_id = NEW.student_id 
    AND qa.is_completed = TRUE
    AND q.course_id = (SELECT course_id FROM public.quizzes WHERE id = NEW.quiz_id)
  GROUP BY q.course_id
  ON CONFLICT (student_id, course_id) 
  DO UPDATE SET
    total_quizzes_taken = EXCLUDED.total_quizzes_taken,
    average_score = EXCLUDED.average_score,
    last_activity = EXCLUDED.last_activity,
    updated_at = NOW();
    
  RETURN NEW;
END;
$$ LANGUAGE plpgsql SECURITY DEFINER;

-- Trigger to update analytics when quiz is completed
CREATE OR REPLACE TRIGGER on_quiz_completed
  AFTER UPDATE OF is_completed ON public.quiz_attempts
  FOR EACH ROW 
  WHEN (NEW.is_completed = TRUE AND OLD.is_completed = FALSE)
  EXECUTE FUNCTION public.update_student_analytics();
