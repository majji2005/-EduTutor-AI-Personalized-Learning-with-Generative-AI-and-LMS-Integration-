import { type NextRequest, NextResponse } from "next/server"
import { GoogleClassroomService } from "@/lib/google-classroom"
import { supabaseServer } from "@/lib/supabase-server"

export async function GET(request: NextRequest) {
  try {
    const { searchParams } = new URL(request.url)
    const userId = searchParams.get("userId")

    if (!userId) {
      return NextResponse.json({ error: "User ID required" }, { status: 400 })
    }

    // Get user's Google Classroom integration
    const { data: integration } = await supabaseServer
      .from("google_classroom_integrations")
      .select("*")
      .eq("user_id", userId)
      .single()

    if (!integration) {
      return NextResponse.json({ error: "Google Classroom not connected" }, { status: 404 })
    }

    // Fetch courses from Google Classroom
    const classroomService = new GoogleClassroomService(integration.access_token)
    const courses = await classroomService.getCourses()

    return NextResponse.json({ courses })
  } catch (error) {
    console.error("Error fetching courses:", error)
    return NextResponse.json({ error: "Failed to fetch courses" }, { status: 500 })
  }
}
