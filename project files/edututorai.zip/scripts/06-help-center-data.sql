-- Insert help categories
INSERT INTO public.help_categories (name, description, icon, order_index) VALUES
  ('Getting Started', 'Basic setup and first steps', 'play-circle', 1),
  ('Account Management', 'Managing your profile and settings', 'user', 2),
  ('Courses & Learning', 'Everything about courses and learning paths', 'book-open', 3),
  ('Quizzes & Assessments', 'Quiz creation and taking assessments', 'clipboard-list', 4),
  ('Google Classroom', 'Integration with Google Classroom', 'google', 5),
  ('Technical Support', 'Technical issues and troubleshooting', 'settings', 6);

-- Insert sample help articles
INSERT INTO public.help_articles (category_id, title, content, slug) VALUES
  (
    (SELECT id FROM public.help_categories WHERE name = 'Getting Started'),
    'How to Create Your First Account',
    '# Creating Your Account

To get started with Edututor AI, follow these simple steps:

## For Students
1. Click on "Student Login" in the top navigation
2. Select "Sign up" if you don''t have an account
3. Fill in your details and verify your email
4. Start exploring courses and taking quizzes!

## For Educators
1. Click on "Educator Login" in the top navigation  
2. Select "Sign up" to create your educator account
3. Complete your profile with teaching credentials
4. Begin creating courses and managing students

## Need Help?
Contact our support team if you encounter any issues during registration.',
    'create-first-account'
  ),
  (
    (SELECT id FROM public.help_categories WHERE name = 'Google Classroom'),
    'Connecting Google Classroom',
    '# Google Classroom Integration

Seamlessly sync your Google Classroom courses with Edututor AI.

## Setup Process
1. Go to your dashboard settings
2. Click "Connect Google Classroom"
3. Authorize the connection with your Google account
4. Select which courses to sync
5. Enable automatic grade passback (optional)

## Features
- **Course Sync**: Import your Google Classroom courses
- **Student Roster**: Automatically sync student lists
- **Assignment Integration**: Push quiz results back to Google Classroom
- **Grade Passback**: Automatic grade synchronization

## Troubleshooting
If you encounter issues:
- Ensure you have teacher permissions in Google Classroom
- Check that third-party apps are enabled in your Google Workspace
- Contact support for advanced configuration help',
    'google-classroom-integration'
  );

-- Insert admin user (you'll need to update the ID after creating the admin account)
INSERT INTO public.admin_settings (key, value, description) VALUES
  ('site_maintenance', '{"enabled": false, "message": "Site is under maintenance"}', 'Site maintenance mode settings'),
  ('google_classroom_enabled', '{"enabled": true}', 'Enable/disable Google Classroom integration'),
  ('max_quiz_questions', '{"value": 50}', 'Maximum number of questions per quiz'),
  ('support_email', '{"email": "support@edututor.ai"}', 'Support contact email');
