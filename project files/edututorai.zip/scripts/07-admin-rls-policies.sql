-- Help center policies
ALTER TABLE public.help_categories ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.help_articles ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.support_tickets ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.support_ticket_replies ENABLE ROW LEVEL SECURITY;

-- Anyone can view published help content
CREATE POLICY "Anyone can view help categories" ON public.help_categories
  FOR SELECT USING (true);

CREATE POLICY "Anyone can view published articles" ON public.help_articles
  FOR SELECT USING (is_published = true);

-- Users can create support tickets
CREATE POLICY "Users can create support tickets" ON public.support_tickets
  FOR INSERT WITH CHECK (auth.uid() = user_id);

CREATE POLICY "Users can view own tickets" ON public.support_tickets
  FOR SELECT USING (auth.uid() = user_id OR EXISTS (
    SELECT 1 FROM public.profiles WHERE id = auth.uid() AND role = 'admin'
  ));

-- Admin policies
CREATE POLICY "Admins can manage help content" ON public.help_articles
  FOR ALL USING (EXISTS (
    SELECT 1 FROM public.profiles WHERE id = auth.uid() AND role = 'admin'
  ));

CREATE POLICY "Admins can manage support tickets" ON public.support_tickets
  FOR ALL USING (EXISTS (
    SELECT 1 FROM public.profiles WHERE id = auth.uid() AND role = 'admin'
  ));

-- Google Classroom integration policies
ALTER TABLE public.google_classroom_integrations ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.google_classroom_courses ENABLE ROW LEVEL SECURITY;

CREATE POLICY "Users can manage own Google Classroom integration" ON public.google_classroom_integrations
  FOR ALL USING (auth.uid() = user_id);

CREATE POLICY "Users can manage own Google Classroom courses" ON public.google_classroom_courses
  FOR ALL USING (EXISTS (
    SELECT 1 FROM public.google_classroom_integrations 
    WHERE id = integration_id AND user_id = auth.uid()
  ));
