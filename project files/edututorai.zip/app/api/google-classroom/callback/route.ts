import { type NextRequest, NextResponse } from "next/server"
import { GoogleClassroomService } from "@/lib/google-classroom"
import { supabaseServer } from "@/lib/supabase-server"

export async function GET(request: NextRequest) {
  try {
    const { searchParams } = new URL(request.url)
    const code = searchParams.get("code")
    const userId = searchParams.get("state") // Pass user ID as state

    if (!code || !userId) {
      return NextResponse.json({ error: "Missing authorization code or user ID" }, { status: 400 })
    }

    // Exchange code for tokens
    const tokens = await GoogleClassroomService.getTokens(code)

    // Store integration in database
    const { error } = await supabaseServer.from("google_classroom_integrations").upsert({
      user_id: userId,
      google_user_id: tokens.sub || "unknown",
      access_token: tokens.access_token,
      refresh_token: tokens.refresh_token,
      expires_at: new Date(tokens.expiry_date || Date.now() + 3600000).toISOString(),
      scope: tokens.scope,
    })

    if (error) {
      console.error("Database error:", error)
      return NextResponse.json({ error: "Failed to save integration" }, { status: 500 })
    }

    // Redirect back to dashboard with success
    return NextResponse.redirect(new URL("/educator/dashboard?classroom=connected", request.url))
  } catch (error) {
    console.error("Callback error:", error)
    return NextResponse.json({ error: "Authentication failed" }, { status: 500 })
  }
}
